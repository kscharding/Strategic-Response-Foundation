//
//  QSAutomatorPlugIn.m
//  QSAutomatorPlugIn
//
//  Created by Nicholas Jitkoff on 10/28/04.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//

#import "QSAutomatorPlugIn.h"

@implementation QSAutomatorPlugIn


@end
