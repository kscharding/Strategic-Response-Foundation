//
//  QSAutomatorPlugIn_Action.h
//  QSAutomatorPlugIn
//
//  Created by Nicholas Jitkoff on 10/28/04.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//

#import "QSAutomatorPlugIn_Action.h"
#define QSAutomatorPlugIn_Type @"QSAutomatorPlugIn_Type"
@interface QSAutomatorPlugIn_Action : QSActionProvider
{
}
@end

