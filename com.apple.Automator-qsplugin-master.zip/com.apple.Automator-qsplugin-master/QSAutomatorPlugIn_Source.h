//
//  QSAutomatorPlugIn_Source.h
//  QSAutomatorPlugIn
//
//  Created by Nicholas Jitkoff on 10/28/04.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//


#import "QSAutomatorPlugIn_Source.h"

@interface QSAutomatorPlugIn_Source : NSObject
{
}
@end

