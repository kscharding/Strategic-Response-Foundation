This Addon will search, display and then download subtitles for the currently running movie from various subtitle sites.

#########################################################

please understand that we cant even begin to help without [debuglog][1], do not post "do you need [debuglog][1]". YES, we always need [debuglog][1] to debug the addon.

#########################################################

![Set it up by selecting the required subtitle languages to search for] (http://dl.dropbox.com/u/19359762/XBMCSubtitles/s1.jpg)

![Choose services you would like to use for your search](http://dl.dropbox.com/u/19359762/XBMCSubtitles/s2.jpg)

![You can also set various Advanced settings, like default service for movie/tvshow search and subtitle download folder](http://dl.dropbox.com/u/19359762/XBMCSubtitles/s3.jpg)

![After you start the move, start the addon by selecting the subtitle button](http://dl.dropbox.com/u/19359762/XBMCSubtitles/r1.jpg)

![Addon will display the list of subtitles and you can now select the one you like](http://dl.dropbox.com/u/19359762/XBMCSubtitles/r2.jpg)



****NOTE 1****

if you are looking for Addic7ed service -> [look here][2]

  [1]: http://wiki.xbmc.org/index.php?title=Log_file
  [2]: http://forum.xbmc.org/showthread.php?tid=75437&pid=717657#pid717657

